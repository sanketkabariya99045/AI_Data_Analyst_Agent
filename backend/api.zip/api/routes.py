from typing import List

from fastapi import APIRouter, File, UploadFile

from backend.services.upload_service import UploadService

router = APIRouter(
    prefix="/api",
    tags=["Upload"]
)

upload_service = UploadService()


@router.post("/upload")
async def upload_files(files: List[UploadFile] = File(...)):
    result = await upload_service.process_files(files)

    return {
        "status": "success",
        "total_files": len(result),
        "files": result
    }