"""
Agent Manager

Main AI Workflow Orchestrator.

Project:
AI Data Analyst
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import pandas as pd

from agents.planner_agent import planner_agent
from agents.sql_agent import sql_agent
from agents.sql_validator import sql_validator
from database.query_executor import query_executor
from insights.insight_agent import insight_agent


@dataclass
class AgentResponse:
    """
    Final response returned to the API.
    """

    success: bool

    question: str

    sql: str

    dataframe: Optional[pd.DataFrame]

    insight: str

    rows: int

    execution_time: float

    message: str

    error: Optional[str] = None


class AgentManager:
    """
    Coordinates all AI components.
    """

    def run(
        self,
        question: str,
    ) -> AgentResponse:

        try:

            # ----------------------------------
            # STEP 1
            # Planner
            # ----------------------------------

            plan = planner_agent.analyze(question)

            if not plan.requires_sql:

                return AgentResponse(
                    success=False,
                    question=question,
                    sql="",
                    dataframe=None,
                    insight="",
                    rows=0,
                    execution_time=0,
                    message="Planner selected a non-SQL workflow.",
                )

            # ----------------------------------
            # STEP 2
            # SQL Generation
            # ----------------------------------

            sql_result = sql_agent.generate_sql(plan)

            if not sql_result.success:

                return AgentResponse(
                    success=False,
                    question=question,
                    sql="",
                    dataframe=None,
                    insight="",
                    rows=0,
                    execution_time=0,
                    message="SQL generation failed.",
                    error=sql_result.error,
                )

            # ----------------------------------
            # STEP 3
            # SQL Validation
            # ----------------------------------

            validation = sql_validator.validate(
                sql_result.sql
            )

            if not validation.valid:

                return AgentResponse(
                    success=False,
                    question=question,
                    sql=sql_result.sql,
                    dataframe=None,
                    insight="",
                    rows=0,
                    execution_time=0,
                    message=validation.message,
                )

            # ----------------------------------
            # STEP 4
            # Execute SQL
            # ----------------------------------

            query_result = query_executor.execute(
                sql_result.sql
            )

            dataframe = query_result["data"]

            # ----------------------------------
            # STEP 5
            # Generate Business Insight
            # ----------------------------------

            insight_result = insight_agent.generate(
                question=question,
                dataframe=dataframe,
            )

            if insight_result.success:
                insight = insight_result.summary
            else:
                insight = "Unable to generate business insights."

            # ----------------------------------
            # STEP 6
            # Final Response
            # ----------------------------------

            return AgentResponse(
                success=True,
                question=question,
                sql=sql_result.sql,
                dataframe=dataframe,
                insight=insight,
                rows=query_result["rows"],
                execution_time=query_result["execution_time"],
                message="Analysis completed successfully.",
            )

        except Exception as error:

            return AgentResponse(
                success=False,
                question=question,
                sql="",
                dataframe=None,
                insight="",
                rows=0,
                execution_time=0,
                message="Unexpected error.",
                error=str(error),
            )


agent_manager = AgentManager()