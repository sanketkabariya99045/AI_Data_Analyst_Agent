"""
Chart Agent

AI Visualization Orchestrator.

Project:
AI Data Analyst
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import pandas as pd

from backend.charts.chart_generator import chart_generator
from backend.charts.chart_models import ChartRequest
from backend.insights.insight_agent import insight_agent


@dataclass
class ChartAgentResponse:
    """
    Final response returned by Chart Agent.
    """

    success: bool

    figure: object | None

    chart_type: str

    explanation: str

    warnings: list[str]

    error: Optional[str] = None


class ChartAgent:
    """
    Coordinates visualization generation.
    """

    def generate(
        self,
        question: str,
        dataframe: pd.DataFrame,
    ) -> ChartAgentResponse:

        try:

            # ----------------------------------
            # Step 1
            # Build request
            # ----------------------------------

            request = ChartRequest(
                question=question,
                dataframe=dataframe,
            )

            # ----------------------------------
            # Step 2
            # Generate chart
            # ----------------------------------

            chart_result = chart_generator.generate(
                request
            )

            if not chart_result.success:

                return ChartAgentResponse(
                    success=False,
                    figure=None,
                    chart_type="",
                    explanation="",
                    warnings=[],
                    error=chart_result.error,
                )

            # ----------------------------------
            # Step 3
            # Generate AI explanation
            # ----------------------------------

            insight = insight_agent.generate(
                question=question,
                dataframe=dataframe,
            )

            explanation = ""

            if insight.success:
                explanation = insight.summary

            # ----------------------------------
            # Step 4
            # Return response
            # ----------------------------------

            return ChartAgentResponse(
                success=True,
                figure=chart_result.figure,
                chart_type=chart_result.chart_type.value,
                explanation=explanation,
                warnings=chart_result.warnings,
            )

        except Exception as error:

            return ChartAgentResponse(
                success=False,
                figure=None,
                chart_type="",
                explanation="",
                warnings=[],
                error=str(error),
            )


chart_agent = ChartAgent()